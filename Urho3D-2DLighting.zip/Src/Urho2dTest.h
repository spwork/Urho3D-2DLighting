#pragma once


#include <Urho3D/Urho3DAll.h>
#include "Urho3DAliases.h"
#include "CameraController.h"
class Point
{
public:
	int x;
	int y;
	bool operator==(Point p2)
	{
		return p2.x == x && p2.y == y;
	}
	StringHash ToHash()
	{
		return StringHash(x + 100 * y);
	}
};
class Urho2DTest :public Application
{

	URHO3D_OBJECT(Urho2DTest,Application)

public:
	Urho2DTest(Context* context);
	virtual void Setup();
	virtual void Start();
	virtual void Stop();
	float ttt = 0;
	RenderPath* rpp = nullptr;
	HashSet<Point*> list;
protected:

	virtual String GetScreenJoystickPatchString()const { return String::EMPTY; }

	void UpdateLightMapSoft(Node* node);
	void InitMouseModeAndLoadL10nFiles(MouseMode mode, const String&  FileNames);

	SharedPtr<Scene> scene_;
	SharedPtr<Node> cameraNode_;
	Camera* camera_;

	float yaw_;
	float pitch_;
	Node* pickedNode = nullptr;
	bool IsInBasket = false;
	bool clockPause = false;
	Node* point,* point2,* point3;

	MouseMode useMouseMode_;

	List<Vector2> poses;

	String LightNames[2] = { "LightHard","LightSoft" };


	SharedPtr<VertexBuffer> vertexBuffer_;

	SharedPtr<IndexBuffer> rectangleIndexBuffer_;

	bool DepthMapDirty = true;


private:
	void CreateConsoleAndDebugHud();
	void SubscribeToEvents();
	void UpdateLightMapHard(Node* node );
	void CreateCollFromJson(Node* node, const String& FileName, const Sprite2D* spr2d,int index = 0);
	void HandleMouseModeRequest(StringHash eventType, VariantMap& eventData);
	/// Handle request for mouse mode change on web platform.
	void HandleMouseModeChange(StringHash eventType, VariantMap& eventData);
	/// Handle key down event to process key controls common to all samples.
	void HandleKeyDown(StringHash eventType, VariantMap& eventData);
	/// Handle key up event to process key controls common to all samples.
	void HandleKeyUp(StringHash eventType, VariantMap& eventData);
	/// Handle scene update event to control camera's pitch and yaw for all samples.
	void HandleSceneUpdate(StringHash eventType, VariantMap& eventData);

	void HandleUpdate(StringHash eventType, VariantMap& eventData);

	void HandleMouseButtonDown(StringHash eventType, VariantMap& eventData);
	Vector2 GetMousePosInWorld();
	/// Handle touch begin event to initialize touch input on desktop platform.
	void CreateUI();

	void CreateScene();
	void CreateLights();
	void HandleEndAllViewsRender(StringHash eventType, VariantMap& eventData);
	void InitLowRender();

	void SetupViewport();
	/// Screen joystick index for navigational controls (mobile platforms only).
	unsigned screenJoystickIndex_;
	/// Screen joystick index for settings (mobile platforms only).
	unsigned screenJoystickSettingsIndex_;
	/// Pause flag.
	bool paused_;
};

