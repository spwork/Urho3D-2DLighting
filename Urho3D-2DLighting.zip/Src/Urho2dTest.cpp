#include "Urho2dTest.h"

#include <Urho3D/Scene/SceneEvents.h>

#include <Urho3D/Core/CoreEvents.h>

#include <Urho3D/Scene/SceneEvents.h>

#include <Urho3D/Scene/SceneEvents.h>
#include "Global.h"


#include <Urho3D/Math/MathDefs.h>
//#define TESTDATA 
URHO3D_DEFINE_APPLICATION_MAIN(Urho2DTest)

Urho2DTest::Urho2DTest(Context* context) :
	Application(context), yaw_(0.0f),
	pitch_(0.f),
	useMouseMode_(MM_ABSOLUTE),
	screenJoystickIndex_(M_MAX_UNSIGNED),
	screenJoystickSettingsIndex_(M_MAX_UNSIGNED),
	paused_(false)
{
	context->RegisterFactory<CameraController>();
	context->RegisterSubsystem<Global>();
}

void Urho2DTest::Setup()
{
	engineParameters_[EP_WINDOW_TITLE] = GetTypeName();
	engineParameters_[EP_LOG_NAME] = GetSubsystem<FileSystem>()->GetAppPreferencesDir("urho3d", "logs") + GetTypeName() + ".log";
	engineParameters_[EP_FULL_SCREEN] = false;
	engineParameters_[EP_HEADLESS] = false;
	engineParameters_[EP_SOUND] = false;
	engineParameters_[EP_WINDOW_HEIGHT] = 900;
	engineParameters_[EP_WINDOW_WIDTH] = 1600;
	engineParameters_[EP_WINDOW_RESIZABLE] = true;

	if (!engineParameters_.Contains(EP_RESOURCE_PREFIX_PATHS))
		engineParameters_[EP_RESOURCE_PREFIX_PATHS] = ";../../Resources;./Resources";

	engineParameters_[EP_RESOURCE_PATHS] = "GameData;CoreData;Data";

}

void Urho2DTest::Start()
{
	CACHE->SetAutoReloadResources(true);
	CreateConsoleAndDebugHud();
	InitMouseModeAndLoadL10nFiles(MM_FREE, "Lang.json");
	CreateUI();
	CreateScene();
	SetupViewport();
	SubscribeToEvents();
	CreateLights();
	InitLowRender();

	SETDEV(0, "LeftClick   ----   HardLight\n\nRightClick   ----   SoftLight\n\nJ   ----   ShowDepthMap");
}

void Urho2DTest::Stop()
{
	engine_->DumpResources(true);
}


void Urho2DTest::UpdateLightMapSoft(Node* node)
{
	auto tex = CACHE->GetResource<Texture2D>("Occlusion");
	auto OcclusionWidth = tex->GetWidth();
	auto OcclusionHeight = tex->GetHeight();


	int* dataOcclusion = (int*)malloc(OcclusionWidth * OcclusionHeight * 4);
	if (dataOcclusion == nullptr)
	{
#ifdef _WIN32
		MessageBoxEx(0, "Err", 0, 0, 0);
#endif // _WIN32
		return;
	}
	tex->GetData(0, dataOcclusion);

	const auto deepMapWidth = 360;

	int* dataDepth = (int*)malloc(deepMapWidth * 4);
	auto occcam = scene_->GetChild("CameraNode2")->GetComponent<Camera>();


	memset(dataDepth, 0xFF, deepMapWidth * 4);

	poses = List<Vector2>();
	auto lightnode = node->GetChild(0u);
	auto lightpos = lightnode->GetWorldPosition2D();
	auto radius = lightnode->GetWorldScale2D().x_ * 0.5f;

	for (float i = 0; i < 360.f; i += (360.f / deepMapWidth))
		for (float j = 0; j < radius; j += .01f)
		{
			float y = -sin(i / 180.f * 3.1415926f) * j + lightpos.y_;
			float x = cos(i / 180.f * 3.1415926f) * j + lightpos.x_;

#ifdef TESTDATA

			poses.Insert(poses.End(), Vector2(x, y));
#endif // TESTDATA


			auto pos = occcam->WorldToScreenPoint(Vector3(x, y, 0.f));

			int xx = pos.x_ * OcclusionWidth;
			int yy = pos.y_ * OcclusionHeight;
			if (xx < 0)xx = 0;
			if (xx > OcclusionWidth)xx = OcclusionWidth - 1;
			if (yy < 0)yy = 0;
			if (yy > OcclusionHeight)yy = OcclusionHeight;


			int k = dataOcclusion[xx + yy * OcclusionWidth];


			//if (d == 0xFFFFFFFF)
			if (k > 0x80000000)
			{

				auto l = (int)(i * (deepMapWidth / 360));
				if (l >= deepMapWidth) l = deepMapWidth - 1;
				dataDepth[l] = 0xFFFFFFFF;
				auto m = (char*)&dataDepth[l];
				m[0] = (j / radius) * 0xFF;
				break;
			}
		}


	SharedPtr<Texture2D> tex2(new Texture2D(context_));

	tex2->SetSize(deepMapWidth, 1, Graphics::GetRGBAFormat(), Urho3D::TextureUsage::TEXTURE_DYNAMIC);
	tex2->SetData(0, 0, 0, deepMapWidth, 1, dataDepth);

	auto spr = lightnode->GetComponent<StaticSprite2D>();

	spr->GetCustomMaterial()
		->SetTexture(TextureUnit::TU_NORMAL, tex2);

//	File file(context_, "d:/2.dat", FILE_WRITE);
//	file.Write(dataDepth, deepMapWidth * 4);
//	file.Close();

	free(dataOcclusion); free(dataDepth);

}



void Urho2DTest::InitMouseModeAndLoadL10nFiles(MouseMode mode, const String& FileNames)
{

	useMouseMode_ = mode;

	Input* input = GetSubsystem<Input>();

	if (GetPlatform() != "Web")
	{
		if (useMouseMode_ == MM_FREE)
			input->SetMouseVisible(true);

		Console* console = GetSubsystem<Console>();
		if (useMouseMode_ != MM_ABSOLUTE)
		{
			input->SetMouseMode(useMouseMode_);
			if (console && console->IsVisible())
				input->SetMouseMode(MM_ABSOLUTE, true);
		}
	}
	else
	{
		input->SetMouseVisible(true);
		SubscribeToEvent(E_MOUSEBUTTONDOWN, URHO3D_HANDLER(Urho2DTest, HandleMouseModeRequest));
		SubscribeToEvent(E_MOUSEMODECHANGED, URHO3D_HANDLER(Urho2DTest, HandleMouseModeChange));
	}


	auto l10n = LOCALIZATION;

	l10n->LoadJSONFile(FileNames);
}

void Urho2DTest::CreateConsoleAndDebugHud()
{

	// Get default style
	ResourceCache* cache = GetSubsystem<ResourceCache>();
	XMLFile* xmlFile = cache->GetResource<XMLFile>("UI/DefaultStyle.xml");

	// Create console
	Console* console = engine_->CreateConsole();
	console->SetDefaultStyle(xmlFile);
	console->GetBackground()->SetOpacity(0.8f);

	// Create debug HUD.
	DebugHud* debugHud = engine_->CreateDebugHud();
	debugHud->SetDefaultStyle(xmlFile);
}

void Urho2DTest::SubscribeToEvents()
{
	// Subscribe key down event
	SubscribeToEvent(E_KEYDOWN, URHO3D_HANDLER(Urho2DTest, HandleKeyDown));
	// Subscribe key up event
	SubscribeToEvent(E_KEYUP, URHO3D_HANDLER(Urho2DTest, HandleKeyUp));
	// Subscribe scene update event
	SubscribeToEvent(E_SCENEUPDATE, URHO3D_HANDLER(Urho2DTest, HandleSceneUpdate));

	SubscribeToEvent(E_ENDALLVIEWSRENDER, URHO3D_HANDLER(Urho2DTest, HandleEndAllViewsRender));

	SubscribeToEvent(E_UPDATE, URHO3D_HANDLER(Urho2DTest, HandleUpdate));
	SubscribeToEvent(E_POSTRENDERUPDATE, [=](StringHash eventType, VariantMap& eventData)
		{
			//if (!DrawDebugGeometry_)return;

			DebugRenderer* dbgRenderer = scene_->GetOrCreateComponent<DebugRenderer>();
			if (dbgRenderer)
			{
				//����navmesh����
				//	auto navMesh = scene_->GetComponent<PhysicsWorld2D>();
				//`	navMesh->DrawDebugGeometry(dbgRenderer, false);
			}
		});
	SubscribeToEvent(E_MOUSEBUTTONDOWN, URHO3D_HANDLER(Urho2DTest, HandleMouseButtonDown));

}

void Urho2DTest::UpdateLightMapHard(Node* node)
{


	node = node->GetChild(0u);
	auto spr = node->GetComponent<StaticSprite2D>();

	auto rc = spr->GetDrawRect();

	rc.min_ = node->LocalToWorld2D(rc.min_);
	rc.max_ = node->LocalToWorld2D(rc.max_);

	auto cam = scene_->GetChild("CameraNode2")->GetComponent<Camera>();
	rc.min_ = cam->WorldToScreenPoint(Vector3(rc.min_, 0.f));
	rc.max_ = cam->WorldToScreenPoint(Vector3(rc.max_, 0.f));

	auto data = (float*)&rc;

	
	Swap(data[1], data[3]);


	Graphics* graphics = GetSubsystem<Graphics>();
	ResourceCache* cache = GetSubsystem<ResourceCache>();
	auto input = GetSubsystem<Input>();

	SharedPtr<Texture2D> texDepth( new Texture2D(context_));
	texDepth->SetNumLevels(1);
	texDepth->SetSize(360*4, 1,  Graphics::GetRGBAFormat(), TEXTURE_RENDERTARGET );
	// ����ݧ��ѧ֧� ��ѧ٧ݧڧ�ߧ��� �ӧѧ�ڧѧ�ڧ� ��ҧ֧��֧ۧէ֧��.

	if (!input->GetKeyDown(KEY_J))
	{

	graphics->SetRenderTarget(0, texDepth);
	graphics->SetViewport(IntRect(0, 0, 360*4, 1));

	}
	
	// ���֧ۧէ֧� �٧ѧܧ�ѧ�ڧӧѧ֧� �ԧ֧�ާ֧��ڧ� �ҧ֧ݧ��� ��ӧ֧��� (�� �էѧߧߧ�� ���ڧާ֧�� �ߧ� �ڧ���ݧ�٧�֧���).
	ShaderVariation* vs = graphics->GetShader(VS, "MyLightDepth");
	ShaderVariation* ps = graphics->GetShader(PS, "MyLightDepth");


	// ���֧ۧէ֧� �ߧѧܧݧѧէ��ӧѧ֧� ��֧ܧ�����.
	ShaderVariation* vsDiff = graphics->GetShader(VS, "MyLightDepth", "DIFFMAP");
	ShaderVariation* psDiff = graphics->GetShader(PS, "MyLightDepth", "DIFFMAP");
	

	// �����֧� �ԧݧ�ҧڧߧ� �ߧ� �ڧ���ݧ�٧�֧���, ��ڧԧ��� �ߧѧܧݧѧէ��ӧѧ���� �� �����էܧ� ����ڧ��ӧܧ�.
	graphics->SetDepthTest(CMP_ALWAYS);
	graphics->SetDepthWrite(false);

	graphics->SetVertexBuffer(vertexBuffer_);
;
	graphics->SetTexture(TU_DIFFUSE, cache->GetResource<Texture2D>("Occlusion"));
	

	// ���ڧ��֧� �٧ѧ�֧ܧ����֧ߧߧ��� �ܧӧѧէ�ѧ� (�ܧ������� �ӧ��ԧݧ�էڧ� �ܧѧ� ����ާ��ԧ�ݧ�ߧڧ�).
	graphics->SetIndexBuffer(rectangleIndexBuffer_);
	graphics->SetShaders(vsDiff, psDiff);
	graphics->SetShaderParameter(VSP_MODEL, Matrix3x4::IDENTITY);
	graphics->SetShaderParameter(VSP_VIEWPROJ, Matrix4::IDENTITY);

	
	graphics->SetShaderParameter("Rect", Vector4(data));
	graphics->Draw(TRIANGLE_LIST, 0, 6, 3, 4);


	if (input->GetKeyDown(KEY_1))
	{
		texDepth->GetImage()->SavePNG("d:/111.png");
		auto w = texDepth->GetWidth();
		auto data = malloc(w * 4);
		texDepth->GetData(0, data);
		File file(context_, "D:/1.dat", FILE_WRITE);
		file.Write(data, w * 4);
		file.Close();
	}

	spr->GetCustomMaterial()
		->SetTexture(TextureUnit::TU_NORMAL, texDepth); ;

}

void Urho2DTest::CreateCollFromJson(Node* node, const String& FileName, const Sprite2D* spr2d, int index)
{

	auto jroot = GET_JSON_FILE(FileName)->GetRoot();
	auto height = spr2d->GetTexture()->GetHeight();
	auto width = spr2d->GetTexture()->GetWidth();
	auto size = height > width ? height : width;

	auto jarray = jroot.Get("rigidBodies").GetArray()[index].Get("polygons").GetArray();

	for (auto jp : jarray)
	{
		auto jarray2 = jp.GetArray();
		PODVector<Vector2> vs;
		for (auto j : jarray2)
		{
			vs.Push(Vector2(j.Get("x").GetFloat() * size / 100.f - size / 200.f, j.Get("y").GetFloat() * size / 100.f - height / 200.f));
		}

		node->CreateComponent<CollisionPolygon2D>()->SetVertices(vs);
		node->CreateComponent<CollisionPolygon2D>()->SetFriction(1.f);

	}
}

void Urho2DTest::HandleMouseModeRequest(StringHash eventType, VariantMap& eventData)
{

	Console* console = GetSubsystem<Console>();
	if (console && console->IsVisible())
		return;
	Input* input = GetSubsystem<Input>();
	if (useMouseMode_ == MM_ABSOLUTE)
		input->SetMouseVisible(false);
	else if (useMouseMode_ == MM_FREE)
		input->SetMouseVisible(true);
	input->SetMouseMode(useMouseMode_);

}

void Urho2DTest::HandleMouseModeChange(StringHash eventType, VariantMap& eventData)
{
	Input* input = GetSubsystem<Input>();
	bool mouseLocked = eventData[MouseModeChanged::P_MOUSELOCKED].GetBool();
	input->SetMouseVisible(!mouseLocked);
}

void Urho2DTest::HandleKeyDown(StringHash eventType, VariantMap& eventData)
{

	using namespace KeyDown;

	int key = eventData[P_KEY].GetInt();

	// Toggle console with F1
	if (key == KEY_F1)
		GetSubsystem<Console>()->Toggle();

	// Toggle debug HUD with F2
	else if (key == KEY_F2)
		GetSubsystem<DebugHud>()->ToggleAll();
	// Common rendering quality controls, only when UI has no focused element
	else if (key == KEY_SPACE)
	{
		CreateLights();
	}
	else if (key == KEY_F)
	{
		DepthMapDirty = true;
	}
	
	else if (key == KEY_V)
	{
		PODVector<Node*> nodes;
		scene_->GetChildrenWithTag(nodes, "MyLight");
		auto value = nodes[0]->IsEnabledSelf();
		for (auto node : nodes)
			node->SetEnabledRecursive(!value);
	}
	else if (key == KEY_F5)
	{
		JSONFile jf(context_);
		scene_->SaveJSON(jf.GetRoot());
		jf.SaveFile("D:/111.json");
	}
	else if (key == KEY_F7)
	{
		JSONFile jf(context_);
		jf.LoadFile("D:/111.json");
		scene_->LoadJSON(jf.GetRoot());
	}
	else if (key == KEY_3)
	{
		static auto i = poses.Begin();
		scene_->GetChild("Wall", false)->SetPosition2D(*i);
		i++;
		if (i == poses.End())
			i = poses.Begin();
	}
	else if (key == KEY_F12)
	{
		Image img(context_);

		GRAPHICS->TakeScreenShot(img);

		img.SavePNG("d:/11/111.png");
	}

	else if (!UI->GetFocusElement())
	{
		Renderer* renderer = GetSubsystem<Renderer>();

		// Preferences / Pause
		if (key == KEY_SELECT)
		{
			paused_ = !paused_;

			Input* input = GetSubsystem<Input>();
			if (screenJoystickSettingsIndex_ == M_MAX_UNSIGNED)
			{
				// Lazy initialization
				ResourceCache* cache = GetSubsystem<ResourceCache>();
				screenJoystickSettingsIndex_ = (unsigned)input->AddScreenJoystick(cache->GetResource<XMLFile>("UI/ScreenJoystickSettings_Samples.xml"), cache->GetResource<XMLFile>("UI/DefaultStyle.xml"));
			}
			else
				input->SetScreenJoystickVisible(screenJoystickSettingsIndex_, paused_);
		}

		// Texture quality
		else if (key == '1')
		{
			//int quality = renderer->GetTextureQuality();
			//++quality;
			//if (quality > QUALITY_HIGH)
			//	quality = QUALITY_LOW;
			//renderer->SetTextureQuality(quality);
		}

		// Material quality
		else if (key == '2')
		{
			//int quality = renderer->GetMaterialQuality();
			//++quality;
			//if (quality > QUALITY_HIGH)
			//	quality = QUALITY_LOW;
			//renderer->SetMaterialQuality(quality);
		}

		// Specular lighting
		else if (key == '3')
			renderer->SetSpecularLighting(!renderer->GetSpecularLighting());

		// Shadow rendering
		else if (key == '4')
			renderer->SetDrawShadows(!renderer->GetDrawShadows());

		// Shadow map resolution
		else if (key == '5')
		{
			int shadowMapSize = renderer->GetShadowMapSize();
			shadowMapSize *= 2;
			if (shadowMapSize > 2048)
				shadowMapSize = 512;
			renderer->SetShadowMapSize(shadowMapSize);
		}

		// Shadow depth and filtering quality
		else if (key == '6')
		{
			ShadowQuality quality = renderer->GetShadowQuality();
			quality = (ShadowQuality)(quality + 1);
			if (quality > SHADOWQUALITY_BLUR_VSM)
				quality = SHADOWQUALITY_SIMPLE_16BIT;
			renderer->SetShadowQuality(quality);
		}

		// Occlusion culling
		else if (key == '7')
		{
			bool occlusion = renderer->GetMaxOccluderTriangles() > 0;
			occlusion = !occlusion;
			renderer->SetMaxOccluderTriangles(occlusion ? 5000 : 0);
		}

		// Instancing
		else if (key == '8')
			renderer->SetDynamicInstancing(!renderer->GetDynamicInstancing());

		else if (key == KEY_P)
		{
			File file(context_, "D:/test.xml", FILE_WRITE);



			scene_->SaveXML(file);

		}

		else if (key == KEY_O)
		{
			File file(context_, "D:/testui.json", FILE_WRITE);


		}

	}
}
void Urho2DTest::HandleKeyUp(StringHash eventType, VariantMap& eventData)
{


	using namespace KeyUp;

	int key = eventData[P_KEY].GetInt();

	// Close console (if open) or exit when ESC is pressed
	if (key == KEY_ESCAPE)
	{
		Console* console = GetSubsystem<Console>();
		if (console->IsVisible())
			console->SetVisible(false);
		else
		{
			if (GetPlatform() == "Web")
			{
				GetSubsystem<Input>()->SetMouseVisible(true);
				if (useMouseMode_ != MM_ABSOLUTE)
					GetSubsystem<Input>()->SetMouseMode(MM_FREE);
			}
			else
				engine_->Exit();
		}
	}
}

void Urho2DTest::HandleSceneUpdate(StringHash eventType, VariantMap& eventData)
{


}
void Urho2DTest::HandleUpdate(StringHash eventType, VariantMap& eventData)
{
	auto t = eventData[Update::P_TIMESTEP].GetFloat();
	
	if (INPUT->GetMouseButtonDown(MouseButton::MOUSEB_LEFT))
	{

	auto pos = INPUT->GetMousePosition();
	auto camera = cameraNode_->GetComponent<Camera>();
	auto pos2 = camera->ScreenToWorldPoint(Vector3((float)pos.x_ / GRAPHICS->GetWidth(), (float)pos.y_ / GRAPHICS->GetHeight(), 0.f));
//	pos2.x_ = Round(pos2.x_); pos2.y_ = Round(pos2.y_);
	scene_->GetChild(LightNames[0])->SetPosition(pos2);
	}

}
void Urho2DTest::HandleMouseButtonDown(StringHash eventType, VariantMap& eventData)
{
	using namespace MouseButtonDown;
	auto button = eventData[P_BUTTON].GetInt();
	if (button == 1 || button == 4)
	{

		auto pos = INPUT->GetMousePosition();
		auto camera = cameraNode_->GetComponent<Camera>();
		auto pos2 = camera->ScreenToWorldPoint(Vector3((float)pos.x_ / GRAPHICS->GetWidth(), (float)pos.y_ / GRAPHICS->GetHeight(), 0.f));
		pos2.x_ = Round(pos2.x_); pos2.y_ = Round(pos2.y_);



		//pos2.z_ = 0.f;
		//auto cam = scene_->GetChild("CameraNode2")->GetComponent<Camera>();
		//auto pos3 = cam->WorldToScreenPoint(pos2);


		if (button == 1)
		{
			scene_->GetChild(LightNames[0])->SetPosition(pos2);
		}
		else if (button == 4)
		{


			auto node = scene_->GetChild(LightNames[1]);
			node->SetPosition(pos2);
			UpdateLightMapSoft(node);
		}

	}
}
Vector2 Urho2DTest::GetMousePosInWorld()
{
	auto pos = INPUT->GetMousePosition();
	Graphics* graphics = GetSubsystem<Graphics>();
	Camera* camera = cameraNode_->GetComponent<Camera>();
	Vector3 v3 = camera->ScreenToWorldPoint(Vector3((float)pos.x_ / graphics->GetWidth(), (float)pos.y_ / graphics->GetHeight(), -10));

	return Vector2(v3.x_, v3.y_);
}
void Urho2DTest::CreateUI()
{

	auto root = UI_ROOT;

	auto style = CACHE->GetResource<XMLFile>("UI/DefaultStyle.xml");
	root->SetDefaultStyle(style);

	auto hub = UI->LoadLayout(GET_XML_FILE("UI/Hub.xml"));
	UI_ROOT->AddChild(hub);
}

void Urho2DTest::CreateScene()
{

	scene_ = new Scene(context_);

	scene_->LoadJSON(GET_JSON_FILE("scene.json")->GetRoot());
	cameraNode_ = scene_->GetChild("CameraNode");
	cameraNode_->CreateComponent<CameraController>();

	auto node = scene_->GetChild("Floor");

	for (float x = -10; x < 10; x++)
		for (float y = -10; y < 10; y++)
		{
			auto node2 = node->Clone();
			scene_->AddChild(node2);
			node2->SetPosition2D(x, y);
		}
	node->Remove();
}

void Urho2DTest::CreateLights()
{
	SetRandomSeed(Time::GetSystemTime());
	for (auto name : LightNames)
	{
		auto node = scene_->CreateChild();
		node->LoadJSON(GET_JSON_FILE("Prefabs/MyLight.json")->GetRoot());
		node->SetName(name);
		node->SetPosition2D(Random(-3.f, 3.f), Random(-3.f, 3.f));
		auto spr = node->GetChild(0u)->GetComponent<StaticSprite2D>();
		SharedPtr<Material> mat(spr->GetCustomMaterial()->Clone());
		spr->SetCustomMaterial(mat);

	}



}

void Urho2DTest::HandleEndAllViewsRender(StringHash eventType, VariantMap& eventData)
{

	static auto time = 0;
	if (time++ > 3 || DepthMapDirty)
	{
		time = 0;
		DepthMapDirty = false;

			UpdateLightMapHard(scene_->GetChild(LightNames[0]));
	}

	static auto first = true;
	if (first )
	{
		first = false;
		UpdateLightMapSoft(scene_->GetChild(LightNames[1]));
	}

}
void Urho2DTest::InitLowRender()
{
	vertexBuffer_ = new VertexBuffer(context_);
	vertexBuffer_->SetShadowed(true);

	// ����� �ӧ֧��ڧߧ� ���֧�ԧ�ݧ�ߧڧܧ� �� ��֧����� �ӧ֧��ڧߧ� ����ާ��ԧ�ݧ�ߧڧܧ�.
	vertexBuffer_->SetSize(3 + 4, MASK_POSITION | MASK_COLOR | MASK_TEXCOORD1);

	auto vertexData = (float*)vertexBuffer_->Lock(0, vertexBuffer_->GetVertexCount());
	auto i = 0;


	// ���֧�ӧѧ� �ӧ֧��ڧߧ� ����ާ��ԧ�ݧ�ߧڧܧ� (��ݧ֧ӧ� �ӧӧ֧���).
	vertexData[i++] = -1.f; // x
	vertexData[i++] = 1.f;  // y
	vertexData[i++] = 0.0f;   // z
	((unsigned&)vertexData[i++]) = Color::BLUE.ToUInt(); // ��ӧ֧�
	vertexData[i++] = 0.0f; // u
	vertexData[i++] = 0.0f; // v

	// ������ѧ� �ӧ֧��ڧߧ� ����ާ��ԧ�ݧ�ߧڧܧ� (����ѧӧ� �ӧӧ֧���).
	vertexData[i++] = 1.f; // x
	vertexData[i++] = 1.f; // y
	vertexData[i++] = 0.0f;  // z
	((unsigned&)vertexData[i++]) = Color::MAGENTA.ToUInt(); // ��ӧ֧�
	vertexData[i++] = 1.0f; // u
	vertexData[i++] = 0.0f; // v

	// ����֧��� �ӧ֧��ڧߧ� ����ާ��ԧ�ݧ�ߧڧܧ� (����ѧӧ� �ӧߧڧ٧�).
	vertexData[i++] = 1.f;  // x
	vertexData[i++] = -1.f; // y
	vertexData[i++] = 0.0f;   // z
	((unsigned&)vertexData[i++]) = Color::MAGENTA.ToUInt(); // ��ӧ֧�
	vertexData[i++] = 1.0f; // u
	vertexData[i++] = 1.0f; // v

	// ���֧�ӧ֧��ѧ� �ӧ֧��ڧߧ� ����ާ��ԧ�ݧ�ߧڧܧ� (��ݧ֧ӧ� �ӧߧڧ٧�).
	vertexData[i++] = -1.f; // x
	vertexData[i++] = -1.f; // y
	vertexData[i++] = 0.0f;   // z
	((unsigned&)vertexData[i++]) = Color::MAGENTA.ToUInt(); // ��ӧ֧�
	vertexData[i++] = 0.0f; // u
	vertexData[i++] = 1.0f; // v



	vertexBuffer_->Unlock();

	// ���ߧէ֧ܧ�ߧ��� �ҧ��֧� �էݧ� �ܧӧѧէ�ѧ��.
	rectangleIndexBuffer_ = new IndexBuffer(context_);
	rectangleIndexBuffer_->SetShadowed(true);
	rectangleIndexBuffer_->SetSize(6, false); // ���ӧѧէ�ѧ� ������ڧ� �ڧ� 2-�� ���֧�ԧ�ݧ�ߧڧܧ�� (6 �ӧ֧��ڧ�).

	unsigned short* rectangleIndexData =
		(unsigned short*)rectangleIndexBuffer_->Lock(0, rectangleIndexBuffer_->GetIndexCount());

	// ���ӧѧէ�ѧ� ������ڧ� �ڧ� �էӧ�� ���֧�ԧ�ݧ�ߧڧܧ��:
	// 0 ____ 1
	//  |\   |
	//  | \  |
	//  |  \ |
	//  |___\|
	// 3      2
	// ���֧�ӧ��� ���� �ӧ֧��ڧߧ� �� �ӧ֧��ڧߧߧ�� �ҧ��֧�� �ߧ� ���ߧ������ �� �ܧӧѧէ�ѧ��, ������ާ� �ӧ֧٧է� ���ڧҧѧӧݧ�֧��� 3.
	rectangleIndexData[0] = 0;
	rectangleIndexData[1] = 1;
	rectangleIndexData[2] = 2;

	rectangleIndexData[3] = 2;
	rectangleIndexData[4] = 3;
	rectangleIndexData[5] = 0;

	rectangleIndexBuffer_->Unlock();
}


void Urho2DTest::SetupViewport()
{
	Renderer* renderer = GetSubsystem<Renderer>();


	auto camera = cameraNode_->GetComponent<Camera>();
	// Set up a viewport to the Renderer subsystem so that the 3D scene can be seen
	SharedPtr<Viewport> viewport(new Viewport(context_, scene_, camera));


	SharedPtr<Texture2D>tex(new Texture2D(context_));
	tex->SetName("Occlusion");
	CACHE->AddManualResource(tex);
	tex->SetSize(512, 512, Graphics::GetRGBAFormat(), Urho3D::TEXTURE_RENDERTARGET);

	SharedPtr<Viewport> viewport2(new Viewport(context_, scene_, scene_->GetChild("CameraNode2", false)->GetComponent<Camera>()));
	viewport2->SetRenderPath(GET_XML_FILE("RenderPaths/DrawOcclusion.xml"));
	tex->GetRenderSurface()->SetUpdateMode(RenderSurfaceUpdateMode::SURFACE_UPDATEALWAYS);
	tex->GetRenderSurface()->SetViewport(0, viewport2);

	renderer->SetViewport(0, viewport);
//	scene_->GetChild("CameraNode2")->GetComponent<Camera>()->SetEnabled(false);
}
